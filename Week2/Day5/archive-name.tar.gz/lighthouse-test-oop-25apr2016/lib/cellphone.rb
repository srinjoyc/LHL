class Cellphone < Product

  def initialize (name, price, brand)
    super(name,price,brand)
  end
end
